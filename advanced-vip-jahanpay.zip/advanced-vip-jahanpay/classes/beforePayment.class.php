<?php

	class avBeforePayment{
		
		var $agency;
	
		var $price;
		
		
		
	
	}